//	Include.h
#pragma once
#include "BagInterface.h"
#include "LinkedBag.cpp"
#include "LinkedBag340.cpp"
#include <memory>

using namespace std;